<!-- Start service  -->
<section id="mu-service">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-service-area">
            <!-- Start single service -->
            <div class="mu-service-single">
              <a href="education.php" style="color:#fff;"><span class="fa fa-book"></span></a> 
              <h3>Education</h3>
              <p>To promote the bright children from poor families to have access to quality education, to get equal opportunities for ...</p>
            </div>
            <div class="mu-service-single">
              <a href="peace-unity.php" style="color:#fff;"> <span class="fa fa-users"></span></a>
              <h3>Peace & Unity</h3>
              <p>To work for the establishment of peace and stability in our society. To promote peace, unity and spirit of “Umoja ni Nguvu”...</p>
            </div>
            <div class="mu-service-single">
              <a href="health.php" style="color:#fff;"> <span class="fa fa-table"></span></a>
              <h3>Health</h3>
              <p>To increase the quality, availability and effectiveness of educational and community based programs designed to prevent.. </p>
            </div>
            <!-- Start single service -->
          </div>
        </div>
      </div>
    </div>
</section>
  <!-- End service  -->
