 <!-- Start Slider -->
 <section id="mu-slider">
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img src="assets/img/slider/1.jpg" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4>Welcome To WSF</h4>
        <span></span>
        <h2>Linda Wazee</h2>
        <p>The WSF linda wazee home is to cater for the  needs of the aged including bathing, dressing, cooking and cleaning....</p>
        <a href="linda-wazee.php" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img src="assets/img/slider/4.jpg" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4>We empower the youths</h4>
        <span></span>
        <h2>WSF Bursary</h2>
        <p>This fund has benefited over 35 students, and this is a milestone in the improvement of literacy level and realization of millennium development goals...</p>
        <a href="bursaries.php" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img src="assets/img/slider/7.jpg" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4>We support the community</h4>
        <span></span>
        <h2>WSF Digital Village</h2>
        <p>Aims at providing interested individuals and professionals working in the field of community development in rural areas with a “one-stop-shop” for the retrieval and exchange of development information and data.</p>
        <a href="digital-village.php" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->    
  </section>
  <!-- End Slider -->