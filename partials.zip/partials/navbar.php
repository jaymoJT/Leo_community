
<?php include 'top.php';?>
<section id="mu-menu" >
    <nav class="navbar navbar-default" role="navigation" >  
      <div class="container" >
        <div class="navbar-header">
          <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- LOGO -->              
          <!-- TEXT BASED LOGO -->
          <a class="navbar-brand" href="index.php"><img src="assets/img/logo.jpg" alt="wamusai logo" style="max-width:17%;margin-top:-3%;" /> 
          </a> 
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
            <li class="active"><a href="index.php">Home</a></li>            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">About us <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="profile.php">Our profile</a></li>                
                <li><a href="vision-mission.php">Vision & Mission</a></li>
                <li><a href="service-charter.php">Our Service Charter</a></li> 
                <li><a href="assurance.php">Our Assurance</a></li> 
                <li><a href="partners.php">Our Partners</a></li>    
                <li><a href="team.php">Strategic Leadership</a></li>                
              </ul>
            </li>   
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Programs <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="bursaries.php">Bursaries</a></li>                
                <li><a href="children-elderly-rescue.php">Children / Elderly Rescue</a></li>
                <li><a href="mentorship.php">Mentorship</a></li>  
                <li><a href="safe-water.php">Safe Water</a></li> 
                <li><a href="hiv-aids.php">HIV / AIDs Programmes</a></li> 
                <li><a href="digital-village.php">Digital Village</a></li> 
                <li><a href="linda-wajane.php">Linda Wajane</a></li>    
                <li><a href="linda-wazee.php">Linda Wazee</a></li>     
                <li><a href="talent-dev.php">Talent Nurturing & development</a></li> 
                <li><a href="env-conservation.php">Environmental Conservation</a></li>
              </ul>
            </li>  
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Objectives <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="peace-unity.php">Peace & Unity</a></li>                
                <li><a href="education.php">Education</a></li> 
                <li><a href="health.php">Health</a></li>               
              </ul>
            </li>
            <li><a href="#">Gallery</a></li>        
            <li><a href="contact.php">Contacts</a></li>       
            <li><a href="#" id="mu-search-icon"><i class="fa fa-search"></i></a></li>
          </ul>                     
        </div><!--/.nav-collapse -->        
      </div>     
    </nav>
  </section>
  <!-- End menu -->

