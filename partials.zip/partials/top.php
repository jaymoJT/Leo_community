<header id="mu-header" style="background-color:#561971; color:#fff;">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-header-area">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-left">
                  <div class="mu-top-email">
                    <i class="fa fa-envelope"></i>
                    <span>info@wsf.org</span>
                  </div>
                  <div class="mu-top-phone">
                    <i class="fa fa-phone"></i>
                    <span>(+254) 714 088 823</span>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-right">
                  <nav>
                    <ul class="mu-top-social-nav">
                      <li><a href="#" style="color:#fff;"> <span class="fa fa-facebook"></span></a></li>
                      <li><a href="#" style="color:#fff;"><span class="fa fa-twitter"></span></a></li>
                      <li><a href="#" style="color:#fff;"><span class="fa fa-google-plus"></span></a></li>
                      <li><a href="#" style="color:#fff;"><span class="fa fa-linkedin"></span></a></li>
                      <li><a href="#" style="color:#fff;"><span class="fa fa-youtube"></span></a></li>
                      <a href="#" class="mu-read-more-btn">Donate</a>
                    </ul>
                  </nav>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- End header  -->