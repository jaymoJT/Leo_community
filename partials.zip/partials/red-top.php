<div class="juu" style="background-color:red;"> 
   <div class="container">
       <div class="row">
           <div class="col-md-6">
                <marquee>Welcome to Wamusai Foundation</marquee>
           </div>
           <div class="col-md-6" style="text-align:right;">
               <p>
                  <i class="fab fa-facebook-square"></i>
                  <i class="fab fa-twitter-square"></i>
                  <i class="fab fa-youtube-square"></i>
               </p>
           </div>
       </div>
   </div>
</div>