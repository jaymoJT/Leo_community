<section id="mid-brand">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <a class="navbar-brand" href="index.php"><img src="assets/img/logo.jpg" alt="wamusai logo" style="max-width:35%;margin-bottom:20px;" /> </a>
            </div>
            <div class="col-md-4" style="text-align:center; margin-top:1%; ">
                <i class="fas fa-map-marker-alt" style="text-align:left;"></i>
                <p style="text-align:left;font-size:20px; "><b> P.O. Box 877-50200 <br>
                   Bungoma, Kenya</b>
               </p>
            </div>
            <div class="col-md-4" style="text-align:center; margin-top:1%; " ">
           
                 <p style="text-align:left;"> <i class="fas fa-mobile-alt"></i>: +254717618457/720687782/700038678/736616316 <br>
                 <i class="fas fa-envelope-square"></i>: wamusaisimiyufoundation@gmail.com </p>

               </p>
            </div>
        </div>
    
    </div>
</section>